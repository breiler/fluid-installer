The esptool source package was downloaded from the Espressif release files at
https://github.com/espressif/esptool .
